package com.example.signin;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



//main activity
public class MainActivity extends AppCompatActivity {
    EditText username, password;
    Button submit;
    MyDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        submit = findViewById(R.id.submit);
        db = new MyDatabase(getApplicationContext());

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Employee empObj = new Employee(username.getText().toString(), password.getText().toString());

                if(db.insertEmployee(empObj)){
                    Toast.makeText(getApplicationContext(), "Record inserted successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Record not inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}