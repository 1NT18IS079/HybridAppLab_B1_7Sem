package com.example.signin;

public class Employee {
    String username;
    String password;

    public Employee(String name, String pass){
        this.username = name;
        this.password = pass;
    }

    public String getUsername(){
        return this.username;
    }

    public String getPassword(){
        return this.password;
    }

}
