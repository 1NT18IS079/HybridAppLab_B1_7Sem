package com.example.keerthi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Intent i1 = getIntent();
//        String sum = i1.getStringExtra("Sum");

        Bundle b1 = i1.getExtras();
        String sumVal = b1.getString("Sum");
        String name = b1.getString("name");

        TextView res = findViewById(R.id.res);
        TextView myName = findViewById(R.id.myName);
        res.setText("Sum: " + sumVal);
        myName.setText("My name: " + name);
    }
}