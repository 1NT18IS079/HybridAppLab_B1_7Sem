package com.example.keerthi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toast.makeText(getApplicationContext(), "App started for first time", Toast.LENGTH_SHORT).show();

        EditText Num1 = findViewById(R.id.num1);
        EditText Num2 = findViewById(R.id.num2);
        Button adder = findViewById(R.id.add);
//        TextView result = findViewById(R.id.result);

        adder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double n1 = Double.parseDouble(Num1.getText().toString());
                Double n2 = Double.parseDouble(Num2.getText().toString());
                Double sum = n1 + n2;

                Intent i1 = new Intent(getApplicationContext(), Result.class);
                i1.putExtra("Sum", sum.toString());
                i1.putExtra("name", "Keerthi");
                startActivity(i1);

//                result.setText("Sum: " + Double.toString(sum));
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(getApplicationContext(), "App paused", Toast.LENGTH_SHORT).show();
    }

}